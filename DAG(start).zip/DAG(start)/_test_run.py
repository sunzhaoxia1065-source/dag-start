import sys
import os
sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))

from ts_benchmark.models.model_loader import get_model_info

# 模拟 model_config
model_config = {
    "model_name": "dag.DAG",
    "model_hyper_params": {}
}

print("Testing get_model_info...")
model_info = get_model_info(model_config)
print(f"model_info type: {type(model_info)}")
print(f"model_info: {model_info}")
if model_info is None:
    print("ERROR: model_info is None!")
else:
    print("SUCCESS: model_info loaded correctly")